(* Mathematica Init File *)

Get[ "ProjectInstaller`ProjectInstaller`"]