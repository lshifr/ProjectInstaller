{
        "author" ->
           {
               "name" -> "Leonid Shifrin",
               "email" -> "lshifr@gmail.com",
               "url" -> "http://www.mathprogramming-intro.org"
           },           
        "name" -> "ProjectInstaller",
        "version" -> "1.0",
        "mathematica_version" -> "8.0+",
        "dependencies" -> {},
        "description"-> "Simple web installer for Mathematica projects",
        "url" -> "https://github.com/lshifr/ProjectInstaller",
        "license" ->  "MIT"
}